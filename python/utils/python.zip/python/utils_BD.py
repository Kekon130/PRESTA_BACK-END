RDS_HOST = "prestadatabase.cde0k0q4uo2h.eu-north-1.rds.amazonaws.com"

RDS_USERNAME = "admin"

RDS_PASSWORD = "presta_Admin"

RDS_DB_NAME = "Presta"

# Materiales

POST_LIBRO_QUERY = f'INSERT INTO Libros (Nombre, Cantidad, Unidades_Disponibles, ISBN, Año_de_Publicacion, Asignatura) VALUES (%(Nombre)s, %(Cantidad)s, %(Unidades_Disponibles)s, %(ISBN)s, %(Año_de_Publicacion)s, %(Asignatura)s)'
POST_APUNTE_QUERY = f'INSERT INTO Apuntes (Nombre, Cantidad, Unidades_Disponibles, Autor, Asignatura) VALUES (%(Nombre)s, %(Cantidad)s, %(Unidades_Disponibles)s, %(Autor)s, %(Asignatura)s)'
POST_CALCULADORA_QUERY = f'INSERT INTO Calculadoras (Nombre, Cantidad, Unidades_Disponibles, Modelo) VALUES (%(Nombre)s, %(Cantidad)s, %(Unidades_Disponibles)s, %(Modelo)s)'

GET_LIBROS_QUERY = f'SELECT ID, Nombre, Unidades_Disponibles, ISBN, Asignatura FROM Libros'
GET_APUNTES_QUERY = f'SELECT ID, Nombre, Unidades_Disponibles, Autor, Asignatura FROM Apuntes'
GET_CALCULADORAS_QUERY = f'SELECT ID, Nombre, Unidades_Disponibles, Modelo FROM Calculadoras'

GET_LIBRO_BY_ID_QUERY = f'SELECT ID, Nombre, Cantidad, Unidades_Disponibles, ISBN, Año_de_Publicacion, Asignatura FROM Libros WHERE ID = %(Material_ID)s'
GET_APUNTE_BY_ID_QUERY = f'SELECT ID, Nombre, Cantidad, Unidades_Disponibles, Autor, Asignatura FROM Apuntes WHERE ID = %(Material_ID)s'
GET_CALCULADORA_BY_ID_QUERY = f'SELECT ID, Nombre, Cantidad, Unidades_Disponibles, Modelo FROM Calculadoras WHERE ID = %(Material_ID)s'

UPDATE_LIBRO_QUERY = f'UPDATE Libros SET Nombre = %(Nombre)s, Cantidad = %(Cantidad)s, ISBN = %(ISBN)s, Año_de_Publicacion = %(Año_de_Publicacion)s, Asignatura = %(Asignatura)s  WHERE ID = %(Material_ID)s'
UPDATE_APUNTE_QUERY = f'UPDATE Apuntes SET Nombre = %(Nombre)s, Cantidad = %(Cantidad)s, Autor = %(Autor)s, Asignatura = %(Asignatura)s WHERE ID = %(Material_ID)s'
UPDATE_CALCULADORA_QUERY = f'UPDATE Calculadoras SET Nombre = %(Nombre)s, Cantidad = %(Cantidad)s, Modelo = %(Modelo)s WHERE ID = %(Material_ID)s'

DELETE_LIBRO_QUERY = f'DELETE FROM Libros WHERE ID = %(Material_ID)s'
DELETE_APUNTE_QUERY = f'DELETE FROM Apuntes WHERE ID = %(Material_ID)s'
DELETE_CALCULADORA_QUERY = f'DELETE FROM Calculadoras WHERE ID = %(Material_ID)s'

# Reservas

POST_RESERVA_QUERY = f"INSERT INTO Reservas (Alumno_ID, Alumno_Email, Material_ID, Material_Nombre, Fecha_Inicio, Fecha_Expiracion, Estado) VALUES (%(Alumno_ID)s, %(Alumno_Email)s, %(Material_ID)s, %(Material_Nombre)s, %(Fecha_Inicio)s, %(Fecha_Expiracion)s, %(Estado)s)"

GET_RESERVAS_QUERY = f"SELECT ID, Alumno_Email, Material_Nombre, Fecha_Inicio, Fecha_Expiracion, Estado FROM Reservas"

GET_RESERVAS_BY_ALUMNO_QUERY = f"SELECT ID, Material_Nombre, Fecha_Inicio, Fecha_Expiracion, Estado FROM Reservas WHERE Alumno_ID = %(Alumno_ID)s"

FORMALIZAR_RESERVA_QUERY = f"UPDATE Reservas SET Estado = %(Estado)s WHERE ID = %(Reserva_ID)s"

CANCELAR_RESERVA_QUERY = f"UPDATE Reservas SET Estado = %(Estado)s WHERE ID = %(Reserva_ID)s"

# Prestamos

FORMALIZAR_PRESTAMO_QUERY = f"INSERT INTO Prestamos (Alumno_ID, Alumno_Email,  Gestor_ID, Gestor_Email, Material_ID, Material_Nombre, Fecha_Inicio, Fecha_Expiracion, Estado) VALUES (%(Alumno_ID)s, %(Alumno_Email)s, %(Gestor_ID)s, %(Gestor_Email)s, %(Material_ID)s, %(Material_Nombre)s, %(Fecha_Inicio)s, null, %(Estado)s)"

GET_PRESTAMOS_BY_ALUMNO_QUERY = f"SELECT ID, Gestor_Email, Material_Nombre, Fecha_Inicio, Fecha_Expiracion, Estado FROM Prestamos WHERE Alumno_ID = %(Alumno_ID)s"

GET_PRESTAMOS_QUERY = f"SELECT ID, Alumno_Email, Gestor_Email, Material_Nombre, Fecha_Inicio, Fecha_Expiracion, Estado FROM Prestamos"

FINALIZAR_PRESTAMO_QUERY = f"UPDATE Prestamos SET Fecha_Expiracion = %(Fecha_Expiracion)s, Estado = %(Estado)s WHERE ID = %(Prestamo_ID)s"