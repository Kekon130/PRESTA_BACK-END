from enum import Enum
import boto3

USER_POOL_ID = 'eu-north-1_Ua8jjMA0Z'

CLIENT_ID = '18bmns56n1vseji6i6l0he3upb'

class Rol_Usuario(Enum):
  Administradores = 'Administradores'
  Gestores = 'Gestores'
  Alumnos = 'Alumnos'
  
def checkIfUserExists(email):
  client = boto3.client('cognito-idp')
  
  try:
    users = client.list_users(
      UserPoolId=USER_POOL_ID,
      Filter=f'email = "{email}"'
    )
    
    if 'Users' in users and users['Users'] is not None and len(users['Users']) > 0:
      return users['Users'][0]['Username']
    
    else:
      return None
    
  except ClientError as e:
    print(f"Error searching for user: {e}")
    return None