from enum import Enum

class Estado_Prestamo(Enum):
  En_Prestamo = 'En préstamo'
  Devuelto = 'Devuelto'